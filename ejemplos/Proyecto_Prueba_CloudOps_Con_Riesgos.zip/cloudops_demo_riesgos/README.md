# Mini Inventario — Proyecto de prueba para CloudOps IA

**Solo laboratorio. No apto para producción.** Este ZIP tiene problemas deliberados para validar la calidad del análisis con Gemini. No contiene claves reales ni se conecta a AWS.

## Objetivo
Una API Node.js mínima con endpoints de inventario. El directorio `aws/` incluye una arquitectura AWS ficticia y políticas IAM/S3 de ejemplo con configuraciones inseguras.

## Instrucciones
Sube el ZIP completo al módulo **Análisis inteligente de proyectos** de CloudOps. Elige **Código fuente / Amplify / Elastic Beanstalk** si existe esa opción, y pulsa **Analizar con IA**. Después pregunta al chat: «Enumera los riesgos críticos, su evidencia en archivos y cómo corregirlos».

## Funcionamiento local opcional
`node src/server.js`, después visita `http://localhost:3000/api/products`. **No publiques el servidor en internet:** su finalidad es la auditoría estática de código inseguro.

## Reglas del ejercicio
No afirmes que se ejecutaron pruebas en AWS o escaneos dinámicos. Las conclusiones deben sustentarse en los archivos. Los problemas esperados para evaluación están en una guía separada, no dentro del ZIP.
