// DEMO EDUCATIVA: contiene fallos intencionales. NO desplegar en producción.
const http = require('node:http');
const url = require('node:url');
const fs = require('node:fs');
const PORT = process.env.PORT || 3000;
const products = [
  { id: 1, name: 'Laptop', cost: 2400, stock: 4 },
  { id: 2, name: 'Mouse', cost: 40, stock: 60 },
];
const server = http.createServer((req, res) => {
  // RIESGO: CORS demasiado permisivo para cualquier origen.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  const pathname = url.parse(req.url, true).pathname;
  if (pathname === '/api/products') {
    res.end(JSON.stringify(products));
  } else if (pathname === '/api/admin/inventory') {
    // RIESGO: endpoint de administración sin autenticación ni autorización.
    res.end(JSON.stringify({ internal: true, products, supplierCosts: true }));
  } else if (pathname === '/api/backup') {
    // RIESGO: respaldo descargable sin control de acceso.
    res.end(JSON.stringify({ generatedAt: new Date().toISOString(), products }));
  } else if (pathname === '/api/report') {
    // RIESGO: lecturas síncronas bloquean el event loop bajo carga.
    const content = fs.readFileSync(__filename, 'utf8');
    res.end(JSON.stringify({ sourceLines: content.split('\n').length }));
  } else {
    res.statusCode = 404;
    res.end(JSON.stringify({ error: 'Not found' }));
  }
});
server.listen(PORT, '0.0.0.0', () => console.log('DEMO solo para pruebas, puerto', PORT));
